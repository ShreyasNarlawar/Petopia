import React from 'react'

const FAQ = () => {
  return (
    <div>
      
      <h1>Hello from FAQ</h1>
    </div>
  )
}

export default FAQ
