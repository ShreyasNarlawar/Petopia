import React from 'react'

const Terms = () => {
  return (
    <div>
      
      <h1>Hello from Terms</h1>
    </div>
  )
}

export default Terms
